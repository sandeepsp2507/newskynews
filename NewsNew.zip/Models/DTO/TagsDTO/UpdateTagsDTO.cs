﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewsNew.Models.DTO.TagsDTO
{
    public class UpdateTagsDTO
    {
        public int id { get; set; }
        public string tags { get; set; }
    }
}