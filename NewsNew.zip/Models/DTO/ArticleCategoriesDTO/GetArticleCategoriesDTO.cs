﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewsNew.Models.DTO.ArticleCategoriesDTO
{
    public class GetArticleCategoriesDTO
    {
        public int id { get; set; }
        public Nullable<int> articleid { get; set; }
        public Nullable<int> categoryid { get; set; }
        public string ArticleName { get; set; }
        public string CategoryName { get; set; }
    }
}