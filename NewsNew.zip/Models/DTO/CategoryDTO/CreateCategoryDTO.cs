﻿namespace NewsNew.Models.DTO.CategoryDTO
{
    public class CreateCategoryDTO
    {
        //public int id { get; set; }
        public string name { get; set; }
        public string displayname { get; set; }
    }
}