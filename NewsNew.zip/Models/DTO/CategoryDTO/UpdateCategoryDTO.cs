﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewsNew.Models.DTO.CategoryDTO
{
    public class UpdateCategoryDTO
    {
        public int id { get; set; }
        public string name { get; set; }
        public string displayname { get; set; }
    }
}